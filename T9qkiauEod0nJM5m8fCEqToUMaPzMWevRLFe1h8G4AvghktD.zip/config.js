module.exports = {
    app: {
        token: 'MTAzNzg1MTg1NzQ3NDgzNDU1NA.GZqIVa.hXxOyJRVzwAMtmu5AJizz3C52qg2l9qPTz68ms',
        playing: 'OUVINDO MUSICA JUNTO COM VOCÊ',
        global: true,
        guild: ''
    },

    opt: {
        DJ: {
            enabled: false,
            roleName: '',
            commands: []
        },
        maxVol: 100,
        leaveOnEnd: true,
        loopMessage: false,
        spotifyBridge: true,
        defaultvolume: 75,
        discordPlayer: {
            ytdlOptions: {
                quality: 'highestaudio',
                highWaterMark: 1 << 25
            }
        }
    }
};
